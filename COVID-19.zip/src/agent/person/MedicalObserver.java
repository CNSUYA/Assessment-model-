package agent.person;

import java.util.List;
import java.util.Random;
import COVID_19.COVID_19;
import COVID_19.SystemParameter;
import agent.place.City;
import agent.utils.Cell;
import agent.utils.MoveTarget;
import agent.utils.Point;
import data.source.DataStorage;
import repast.simphony.context.Context;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.grid.Grid;
import repast.simphony.util.ContextUtils;
/**
 * 医学隔离观察者
 */
public class MedicalObserver extends Point {
	public static ContinuousSpace<Object> space;
	public static Grid<Object> grid;
	public static City city;
	private int age;//年龄
	private MoveTarget moveTarget;
	private double temperature;
	private boolean isWearMask;//是否佩戴口罩
	private boolean isVaccination;//是否接种疫苗
	List<Cell> cellTeam = COVID_19.cellTeam;// 太原市边界
	List<Cell> TYMcellTeam = COVID_19.TYMcellTeam;// 太原面
	Random random = new Random();// 随机数
	private int quarantineTime;// 隔离时刻
	private int randomTime;// 隔离时刻
	private String regional; //地域
	
	
	public MedicalObserver(ContinuousSpace<Object> space, Grid<Object> grid, City city, int x, int y,int age,int quarantineTime,double temperature,String regional) {
		super(x, y);
		this.space = space;
		this.grid = grid;
		this.city = city;
		this.age = age;
		this.temperature = temperature;
		this.quarantineTime=quarantineTime;
		this.regional=regional;
	}


	

	public void init() {
		/**
		 * 数据统计
		 */
		DataStorage.dataStorage.setMedicalObserver_Num(DataStorage.dataStorage.getMedicalObserver_Num() + 1);

		regionalStatistics();
		
		this.randomTime=random.nextInt(7)+1;
		
	}


	/**
	 * 隔离医学观察14天
	 */
	@ScheduledMethod(start = 1, interval = 1)
	public void isolatedMedicalObservation() {
		//System.out.println("我康复变为健康者时间"+randomTime);
		System.out.println("当前时间"+SystemParameter.worldTime+"隔离时间"+this.quarantineTime+"随机事件"+this.randomTime);
		if(SystemParameter.worldTime-this.quarantineTime==randomTime) {
			Context<Object> context = ContextUtils.getContext(this);
			context.remove(this);
			HealthyPerson healthyPerson = new HealthyPerson(space, grid, City.getInstance(), this.getX(), this.getY(),
					this.getAge(), this.getTemperature(),this.regional);
			context.add(healthyPerson);
			grid.moveTo(healthyPerson, healthyPerson.getX(), healthyPerson.getY());
			System.out.println("我康复变为健康者了");
			// * 确诊者-1
			DataStorage.dataStorage.setCONFIRMED_Num(DataStorage.dataStorage.getCONFIRMED_Num() - 1);
			// * 隔离医学观察者-1
			DataStorage.dataStorage.setMedicalObserver_Num(DataStorage.dataStorage.getMedicalObserver_Num() - 1);
			/**
			 * 床位数+1
			 */
			DataStorage.dataStorage.setUnuseBedNum(DataStorage.dataStorage.getUnuseBedNum()+1);
			DataStorage.dataStorage.setUseBedNum(DataStorage.dataStorage.getUseBedNum()-1);
			/**
			 * 康复者数据统计
			 */
			DataStorage.dataStorage.setCURED_Num(DataStorage.dataStorage.getCURED_Num() + 1);
			System.out.println("出院");
		}
		
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}

	public boolean isWearMask() {
		return isWearMask;
	}

	public void setWearMask(boolean isWearMask) {
		this.isWearMask = isWearMask;
	}

	public boolean isVaccination() {
		return isVaccination;
	}

	public void setVaccination(boolean isVaccination) {
		this.isVaccination = isVaccination;
	}
	
	public void regionalStatistics() 
	{
		switch (this.regional) {
		case "XD":
			DataStorage.dataStorage.setXDMedicalObserver(DataStorage.dataStorage.getXDMedicalObserver() + 1);
			break;
		case "JCP":
			DataStorage.dataStorage.setJCPMedicalObserver(DataStorage.dataStorage.getJCPMedicalObserver() + 1);
			break;
		case "wbl":
			DataStorage.dataStorage.setWBLMedicalObserver(DataStorage.dataStorage.getWBLMedicalObserver() + 1);
			break;
		case "jy":
			DataStorage.dataStorage.setJYMedicalObserver(DataStorage.dataStorage.getJYMedicalObserver() + 1);
			break;
		case "XHL":
			DataStorage.dataStorage.setXHLMedicalObserver(DataStorage.dataStorage.getXHLMedicalObserver() + 1);
			break;
		case "YZ":
			DataStorage.dataStorage.setYZMedicalObserver(DataStorage.dataStorage.getYZMedicalObserver() + 1);
			break;
		default:
			
			break;
		}
	}
}
